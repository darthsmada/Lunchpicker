﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LunchPicker.Models
{
    public class Cuisine
    {
        public int Id { get; set; }
        public string American { get; set; }
        public string Italian { get; set; }
        public string Mexican { get; set; }
        public string Asian { get; set; }
    }
}