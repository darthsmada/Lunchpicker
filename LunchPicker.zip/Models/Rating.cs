﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LunchPicker
{
    public class Rating
    {
        public int Id { get; set; }
        public string NumberOfStars { get; set; }


        public virtual int RestaurantId { get; set; }
    }
}